version = (0, 9, 0)
version_string = "0.9.0"
release_date = "2012.05.12"
